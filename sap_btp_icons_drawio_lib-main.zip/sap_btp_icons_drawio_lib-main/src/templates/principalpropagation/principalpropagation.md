
# Principal Propagation

Example for principal propagation

![Principal Propagation](./principalpropagation.png)

[Open Diagram](https://app.diagrams.net/?create=https://raw.githubusercontent.com/uxkjaer/sap_btp_icons_drawio_lib/main/src/templates/principalpropagation/principalpropagation.xml&clibs=Uhttps://raw.githubusercontent.com/mauriciolauffer/sap_btp_icons_drawio_lib/main/libs/SAP_BTP_Service_Icons_latest.xml)